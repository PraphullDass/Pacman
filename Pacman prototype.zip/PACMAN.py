#NAME: Praphull Dass
#ROLL NO.: 2018071
#SECTION: A
#GROUP: 7
import pygame
from random import choice,randint

pygame.init()
win2=pygame.display.set_mode((500,100))
pygame.display.set_caption("PACMAN")

coin=pygame.mixer.Sound("coin1.wav")

victory=pygame.mixer.Sound("victory.wav")

crash=pygame.mixer.Sound("crash.wav")

music=pygame.mixer.music.load("fur elise.mp3")
pygame.mixer.music.play(-1)

class player(object):
    def __init__(self,x,y,width,height,score=0,c1=0,c2=0,c3=0,c4=0,d1=0,d2=0,d3=0,d4=0,d5=0,d6=0,d7=0):
        self.x=x
        self.y=y
        self.width=width
        self.height=height
        self.vel=5
        self.p1=randint(55,445)
        self.p2=randint(55,445)
        self.p3=randint(55,445)
        self.p4=randint(55,395)
        self.q1=randint(55,445)
        self.q2=randint(55,445)
        self.q3=randint(55,445)
        self.q4=randint(55,395)
        self.q5=randint(495,885)
        self.q6=randint(495,885)
        self.q7=randint(55,395)
        self.d1=d1
        self.d2=d2
        self.d3=d3
        self.d4=d4
        self.d5=d5
        self.d6=d6
        self.d7=d7
        self.score=score
        self.c1=c1
        self.c2=c2
        self.c3=c3
        self.c4=c4


    def move1(self):
        keys1=pygame.key.get_pressed()
        if keys1[pygame.K_LEFT] and man2.x>man2.vel:
            if man2.y==5 or man2.y==445:
                man2.x-=man2.vel
            elif man2.y==225:
                if man2.x not in range(145,315,5):
                    man2.x-=man2.vel
            elif man2.y==140 or man2.y==310:
                if man2.x in range(145,315,5):
                    man2.x-=man2.vel
        if keys1[pygame.K_RIGHT] and man2.x<500-man2.width-man2.vel:
            if man2.y==5 or man2.y==445:
                man2.x+=man2.vel
            elif man2.y==225:
                if man2.x not in range(140,310,5):
                    man2.x+=man2.vel
            elif man2.y==140 or man2.y==310:
                if man2.x in range(140,310,5):
                    man2.x+=man2.vel
        if keys1[pygame.K_UP] and man2.y>man2.vel:
            if man2.x==5 or man2.x==445:
                man2.y-=man2.vel
            elif man2.x==225:
                if man2.y not in range(145,315,5):
                    man2.y-=man2.vel
            elif man2.x==140 or man2.x==310:
                if man2.y in range(145,315,5):
                    man2.y-=man2.vel
        if keys1[pygame.K_DOWN] and man2.y<500-man2.height-man2.vel:
            if man2.x==5 or man2.x==445:
                man2.y+=man2.vel
            elif man2.x==225:
                if man2.y not in range(140,310,5):
                    man2.y+=man2.vel
            elif man2.x==140 or man2.x==310:
                if man2.y in range(140,310,5):
                    man2.y+=man2.vel
    def move2(self):
        keys2=pygame.key.get_pressed()
        if keys2[pygame.K_LEFT] and man2.x>man2.vel:
            if man2.y==5 or man2.y==445:
                man2.x-=man2.vel
            elif man2.y==225:
                if man2.x not in range(145,315,5) and man2.x not in range(585,755,5):
                    man2.x-=man2.vel
            elif man2.y==140 or man2.y==310:
                if man2.x in range(145,315,5) or man2.x in range(585,755,5):
                    man2.x-=man2.vel
        if keys2[pygame.K_RIGHT] and man2.x<940-man2.width-man2.vel:
            if man2.y==5 or man2.y==445:
                man2.x+=man2.vel
            elif man2.y==225:
                if man2.x not in range(140,310,5) and man2.x not in range(580,750,5):
                    man2.x+=man2.vel
            elif man2.y==140 or man2.y==310:
                if man2.x in range(140,310,5) or man2.x in range(580,750,5):
                    man2.x+=man2.vel
        if keys2[pygame.K_UP] and man2.y>man2.vel:
            if man2.x==5 or man2.x==445 or man2.x==885:
                man2.y-=man2.vel
            elif man2.x==225 or man2.x==665:
                if man2.y not in range(145,315,5):
                    man2.y-=man2.vel
            elif man2.x==140 or man2.x==310 or man2.x==580 or man2.x==750:
                if man2.y in range(145,315,5):
                    man2.y-=man2.vel
        if keys2[pygame.K_DOWN] and man2.y<500-man2.height-man2.vel:
            if man2.x==5 or man2.x==445 or man2.x==885:
                man2.y+=man2.vel
            elif man2.x==225 or man2.x==665:
                if man2.y not in range(140,310,5):
                    man2.y+=man2.vel
            elif man2.x==140 or man2.x==310 or man2.x==580 or man2.x==750:
                if man2.y in range(140,310,5):
                    man2.y+=man2.vel

    def check2(self):
        if self.d1==0:
            if man2.x in range(self.q1-39,self.q1+40) and self.y in range(5,45):
                self.d1=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(self.q1+25,30),15)
        if self.d2==0:
            if man2.x in range(self.q2-39,self.q2+40) and self.y in range(410,450):
                self.d2=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(self.q2+25,470),15)
        if self.d3==0:
            if man2.x in range(5,45) and self.y in range(self.q3-39,self.q3+40):
                self.d3=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(30,self.q3+25),15)
        if self.d4==0:
            if man2.x in range(410,450) and self.y in range(self.q4-39,self.q4+40):
                self.d4=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(470,self.q4+25),15)
        if self.d5==0:
            if man2.x in range(self.q5-39,self.q5+40) and self.y in range(5,45):
                self.d5=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(self.q5+25,30),15)
        if self.d6==0:
            if man2.x in range(self.q6-39,self.q6+40) and self.y in range(410,450):
                self.d6=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(self.q6+25,470),15)
        if self.d7==0:
            if man2.x in range(850,890) and self.y in range(self.q7-39,self.q7+40):
                self.d7=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(910,self.q7+25),15)
        return self.score

    def check1(self):
        if self.c1==0:
            if man2.x in range(self.p1-39,self.p1+40) and self.y in range(5,45):
                self.c1=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(self.p1+25,30),15)
        if self.c2==0:
            if man2.x in range(self.p2-39,self.p2+40) and self.y in range(410,450):
                self.c2=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(self.p2+25,470),15)
        if self.c3==0:
            if man2.x in range(5,45) and self.y in range(self.p3-39,self.p3+40):
                self.c3=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(30,self.p3+25),15)
        if self.c4==0:
            if man2.x in range(410,450) and self.y in range(self.p4-39,self.p4+40):
                self.c4=1
                coin.play()
                self.score+=1
            else:
                pygame.draw.circle(win2,(255,255,0),(470,self.p4+25),15)
        return self.score

class enemy(object):
    def __init__(self,x,y,width,height,m):
        self.x=x
        self.y=y
        self.width=width
        self.height=height
        self.vel=5
        self.m=m
        self.r=""

    def move1(self):
        if self.m==0:
            if self.x==5 and self.y==5:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="DOWN":
                    self.m=1
            if self.x==225 and self.y==5:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="DOWN":
                    self.m=2
            if self.x==445 and self.y==5:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="DOWN":
                    self.m=1
            if self.x==5 and self.y==445:
                self.r=choice(["UP","RIGHT"])
                if self.r=="UP":
                    self.m=1
            if self.x==225 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="UP":
                    self.m=3
            if self.x==445 and self.y==445:
                self.r=choice(["UP","LEFT"])
                if self.r=="UP":
                    self.m=1
            if self.m==0:
                if self.vel>0:
                    if self.x+self.vel<=445:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>10:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==1:
            if self.y==5 and self.x==5:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="RIGHT":
                    self.m=0
            if self.y==225 and self.x==5:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="RIGHT":
                    self.m=4
            if self.y==445 and self.x==5:
                self.r=choice(["UP","RIGHT"])
                if self.r=="RIGHT":
                    self.m=0
            if self.y==5 and self.x==445:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="LEFT":
                    self.m=0
            if self.y==225 and self.x==445:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="LEFT":
                    self.m=5
            if self.x==445 and self.y==445:
                self.r=choice(["UP","LEFT"])
                if self.r=="LEFT":
                    self.m=0
            if self.m==1:
                if self.vel>0:
                    if self.y+self.vel<=445:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>10:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==2:
            if self.x==225 and self.y==5:
                self.r=choice(["ELSE","DOWN"])
                if self.r=="ELSE":
                    self.m=0
            if self.x==225 and self.y==140:
                self.r=choice(["UP","ELSE"])
                if self.r=="ELSE":
                    self.m=6
            if self.m==2:
                if self.vel>0:
                    if self.y+self.vel<=140:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>10:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==3:
            if self.x==225 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="ELSE":
                    self.m=0
            if self.x==225 and self.y==310:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="ELSE":
                    self.m=6
            if self.m==3:
                if self.vel>0:
                    if self.y+self.vel<=445:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>315:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==4:
            if self.y==225 and self.x==5:
                self.r=choice(["ELSE","RIGHT"])
                if self.r=="ELSE":
                    self.m=1
            if self.y==225 and self.x==140:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="ELSE":
                    self.m=7
            if self.m==4:
                if self.vel>0:
                    if self.x+self.vel<=140:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>10:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==5:
            if self.y==225 and self.x==445:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="ELSE":
                    self.m=1
            if self.y==225 and self.x==310:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="ELSE":
                    self.m=7
            if self.m==5:
                if self.vel>0:
                    if self.x+self.vel<=445:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>315:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==6:
            if self.x==140 and self.y==310:
                self.r=choice(["UP","RIGHT"])
                if self.r=="UP":
                    self.m=7
            if self.x==225 and self.y==310:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="DOWN":
                    self.m=3
            if self.x==310 and self.y==310:
                self.r=choice(["UP","LEFT"])
                if self.r=="UP":
                    self.m=7
            if self.x==140 and self.y==140:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="DOWN":
                    self.m=7
            if self.x==225 and self.y==140:
                self.r=choice(["UP","ELSE"])
                if self.r=="UP":
                    self.m=2
            if self.x==310 and self.y==140:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="DOWN":
                    self.m=7
            if self.m==6:
                if self.vel>0:
                    if self.x+self.vel<=310:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>145:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==7:
            if self.y==140 and self.x==310:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="LEFT":
                    self.m=6
            if self.y==225 and self.x==310:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="RIGHT":
                    self.m=5
            if self.x==310 and self.y==310:
                self.r=choice(["UP","LEFT"])
                if self.r=="LEFT":
                    self.m=6
            if self.x==140 and self.y==140:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="RIGHT":
                    self.m=6
            if self.y==225 and self.x==140:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="LEFT":
                    self.m=4
            if self.y==310 and self.x==140:
                self.r=choice(["UP","RIGHT"])
                if self.r=="RIGHT":
                    self.m=6
            if self.m==7:
                if self.vel>0:
                    if self.y+self.vel<=310:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>145:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)

    def move2(self):
        if self.m==0:
            if self.x==5 and self.y==5:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="DOWN":
                    self.m=1
            if self.x==225 and self.y==5:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="DOWN":
                    self.m=2
            if self.x==445 and self.y==5:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="DOWN":
                    self.m=1
            if self.x==665 and self.y==5:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="DOWN":
                    self.m=2
            if self.x==885 and self.y==5:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="DOWN":
                    self.m=1
            if self.x==5 and self.y==445:
                self.r=choice(["UP","RIGHT"])
                if self.r=="UP":
                    self.m=1
            if self.x==225 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="UP":
                    self.m=3
            if self.x==445 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="UP":
                    self.m=1
            if self.x==665 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="UP":
                    self.m=3
            if self.x==885 and self.y==445:
                self.r=choice(["UP","LEFT"])
                if self.r=="UP":
                    self.m=1
            if self.m==0:
                if self.vel>0:
                    if self.x+self.vel<=885:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>10:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==1:
            if self.y==5 and self.x==5:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="RIGHT":
                    self.m=0
            if self.y==225 and self.x==5:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="RIGHT":
                    self.m=4
            if self.y==445 and self.x==5:
                self.r=choice(["UP","RIGHT"])
                if self.r=="RIGHT":
                    self.m=0
            if self.y==5 and self.x==445:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="ELSE":
                    self.m=0
            if self.y==225 and self.x==445:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="LEFT":
                    self.m=5
            if self.x==445 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="ELSE":
                    self.m=0
            if self.x==885 and self.y==5:
                self.r=choice(["LEFT","DOWN"])
                if self.r=="LEFT":
                    self.m=0
            if self.x==885 and self.y==225:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="LEFT":
                    self.m=9
            if self.x==885 and self.y==445:
                self.r=choice(["LEFT","UP"])
                if self.r=="LEFT":
                    self.m=0
            if self.m==1:
                if self.vel>0:
                    if self.y+self.vel<=445:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>10:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==2:
            if self.x==225 and self.y==5:
                self.r=choice(["ELSE","DOWN"])
                if self.r=="ELSE":
                    self.m=0
            if self.x==665 and self.y==5:
                self.r=choice(["ELSE","DOWN"])
                if self.r=="ELSE":
                    self.m=0
            if self.x==225 and self.y==140:
                self.r=choice(["UP","ELSE"])
                if self.r=="ELSE":
                    self.m=6
            if self.x==665 and self.y==140:
                self.r=choice(["UP","ELSE"])
                if self.r=="ELSE":
                    self.m=8
            if self.m==2:
                if self.vel>0:
                    if self.y+self.vel<=140:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>10:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==3:
            if self.x==225 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="ELSE":
                    self.m=0
            if self.x==665 and self.y==445:
                self.r=choice(["UP","ELSE"])
                if self.r=="ELSE":
                    self.m=0
            if self.x==225 and self.y==310:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="ELSE":
                    self.m=6
            if self.x==665 and self.y==310:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="ELSE":
                    self.m=8
            if self.m==3:
                if self.vel>0:
                    if self.y+self.vel<=445:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>315:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==4:
            if self.y==225 and self.x==5:
                self.r=choice(["ELSE","RIGHT"])
                if self.r=="ELSE":
                    self.m=1
            if self.y==225 and self.x==140:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="ELSE":
                    self.m=7
            if self.m==4:
                if self.vel>0:
                    if self.x+self.vel<=140:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>10:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==5:
            if self.y==225 and self.x==445:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="ELSE":
                    self.m=1
            if self.y==225 and self.x==310:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="ELSE":
                    self.m=7
            if self.y==225 and self.x==580:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="ELSE":
                    self.m=7
            if self.m==5:
                if self.vel>0:
                    if self.x+self.vel<=580:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>315:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==6:
            if self.x==140 and self.y==310:
                self.r=choice(["UP","RIGHT"])
                if self.r=="UP":
                    self.m=7
            if self.x==225 and self.y==310:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="DOWN":
                    self.m=3
            if self.x==310 and self.y==310:
                self.r=choice(["UP","LEFT"])
                if self.r=="UP":
                    self.m=7
            if self.x==140 and self.y==140:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="DOWN":
                    self.m=7
            if self.x==225 and self.y==140:
                self.r=choice(["UP","ELSE"])
                if self.r=="UP":
                    self.m=2
            if self.x==310 and self.y==140:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="DOWN":
                    self.m=7
            if self.m==6:
                if self.vel>0:
                    if self.x+self.vel<=310:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>145:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==7:
            if self.y==140 and self.x==310:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="LEFT":
                    self.m=6
            if self.y==225 and self.x==310:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="RIGHT":
                    self.m=5
            if self.x==310 and self.y==310:
                self.r=choice(["UP","LEFT"])
                if self.r=="LEFT":
                    self.m=6
            if self.x==140 and self.y==140:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="RIGHT":
                    self.m=6
            if self.y==225 and self.x==140:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="LEFT":
                    self.m=4
            if self.y==310 and self.x==140:
                self.r=choice(["UP","RIGHT"])
                if self.r=="RIGHT":
                    self.m=6
            if self.y==140 and self.x==750:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="LEFT":
                    self.m=8
            if self.y==225 and self.x==750:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="RIGHT":
                    self.m=9
            if self.x==750 and self.y==310:
                self.r=choice(["UP","LEFT"])
                if self.r=="LEFT":
                    self.m=8
            if self.x==580 and self.y==140:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="RIGHT":
                    self.m=8
            if self.y==225 and self.x==580:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="LEFT":
                    self.m=5
            if self.y==310 and self.x==580:
                self.r=choice(["UP","RIGHT"])
                if self.r=="RIGHT":
                    self.m=8
            if self.m==7:
                if self.vel>0:
                    if self.y+self.vel<=310:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.y-self.vel>145:
                        self.y+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==8:
            if self.x==580 and self.y==140:
                self.r=choice(["DOWN","RIGHT"])
                if self.r=="DOWN":
                    self.m=7
            if self.x==665 and self.y==140:
                self.r=choice(["UP","ELSE"])
                if self.r=="UP":
                    self.m=2
            if self.x==750 and self.y==140:
                self.r=choice(["DOWN","LEFT"])
                if self.r=="DOWN":
                    self.m=7
            if self.x==580 and self.y==310:
                self.r=choice(["UP","RIGHT"])
                if self.r=="UP":
                    self.m=7
            if self.x==665 and self.y==310:
                self.r=choice(["DOWN","ELSE"])
                if self.r=="DOWN":
                    self.m=3
            if self.x==750 and self.y==310:
                self.r=choice(["UP","LEFT"])
                if self.r=="UP":
                    self.m=7
            if self.m==8:
                if self.vel>0:
                    if self.x+self.vel<=750:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>585:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
        if self.m==9:
            if self.x==750 and self.y==225:
                self.r=choice(["RIGHT","ELSE"])
                if self.r=="ELSE":
                    self.m=7
            if self.x==885 and self.y==225:
                self.r=choice(["LEFT","ELSE"])
                if self.r=="ELSE":
                    self.m=1
            if self.m==9:
                if self.vel>0:
                    if self.x+self.vel<=885:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
                else:
                    if self.x-self.vel>755:
                        self.x+=self.vel
                    else:
                        self.vel=self.vel*(-1)
            
        

enemy1=enemy(175,445,50,50,0)
enemy2=enemy(445,275,50,50,1)

man2=player(5,5,50,50)

nametext=""
run0=True
while run0:
    pygame.time.delay(125)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            quit()

    win2.fill((0,0,0))

    name=pygame.font.SysFont("comicsans",35,True,True)
    namedisplay=name.render("ENTER NAME:(max 12 characters)",1,(255,255,255))
    win2.blit(namedisplay,(15,15))
    namedisplay=name.render(str(nametext),1,(255,255,255))
    win2.blit(namedisplay,(15,50))
    pygame.display.update()

    
    keys0=pygame.key.get_pressed()
    i=0
    while i==0:
        if keys0[pygame.K_a]:
            nametext+="A"
        elif keys0[pygame.K_b]:
            nametext+="B"
        elif keys0[pygame.K_c]:
            nametext+="C"
        elif keys0[pygame.K_d]:
            nametext+="D"
        elif keys0[pygame.K_e]:
            nametext+="E"
        elif keys0[pygame.K_f]:
            nametext+="F"
        elif keys0[pygame.K_g]:
            nametext+="G"
        elif keys0[pygame.K_h]:
            nametext+="H"
        elif keys0[pygame.K_i]:
            nametext+="I"
        elif keys0[pygame.K_j]:
            nametext+="J"
        elif keys0[pygame.K_k]:
            nametext+="K"
        elif keys0[pygame.K_l]:
            nametext+="L"
        elif keys0[pygame.K_m]:
            nametext+="M"
        elif keys0[pygame.K_n]:
            nametext+="N"
        elif keys0[pygame.K_o]:
            nametext+="O"
        elif keys0[pygame.K_p]:
            nametext+="P"
        elif keys0[pygame.K_q]:
            nametext+="Q"
        elif keys0[pygame.K_r]:
            nametext+="R"
        elif keys0[pygame.K_s]:
            nametext+="S"
        elif keys0[pygame.K_t]:
            nametext+="T"
        elif keys0[pygame.K_u]:
            nametext+="U"
        elif keys0[pygame.K_v]:
            nametext+="V"
        elif keys0[pygame.K_w]:
            nametext+="W"
        elif keys0[pygame.K_x]:
            nametext+="X"
        elif keys0[pygame.K_y]:
            nametext+="Y"
        elif keys0[pygame.K_z]:
            nametext+="Z"
        elif keys0[pygame.K_RETURN]:
            run0=False
        elif keys0[pygame.K_BACKSPACE]:
            nametext=nametext[:-1]
        elif keys0[pygame.K_SPACE]:
            nametext+=" "
        
        i=1

win2=pygame.display.set_mode((500,550))

font=pygame.font.SysFont("comicsans",30,True,True)
timefont=pygame.font.SysFont("comicsans",30,True,True)
time=0
faketime=0
timefon=pygame.font.SysFont("comicsans",30,True,True)
run1=True
while run1:
    pygame.time.delay(50)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            quit()
    man2.move1()

    if man2.x in range(enemy1.x-49,enemy1.x+50) and man2.y in range(enemy1.y-49,enemy1.y+50) or man2.x in range(enemy2.x-49,enemy2.x+50) and man2.y in range(enemy2.y-49,enemy2.y+50):
        crash.play()
        if man2.score==0:
            pygame.mixer.music.stop()
            game=pygame.font.SysFont("comicsans",50,True,True)
            gamedisplay=game.render("Game",1,(0,0,0))
            win2.blit(gamedisplay,(80,80))
            over=pygame.font.SysFont("comicsans",50,True,True)
            overdisplay=over.render("Over",1,(0,0,0))
            win2.blit(overdisplay,(300,80))
            you=pygame.font.SysFont("comicsans",50,True,True)
            youdisplay=you.render("You",1,(0,0,0))
            win2.blit(youdisplay,(80,385))
            Win=pygame.font.SysFont("comicsans",50,True,True)
            Windisplay=Win.render("Lose",1,(0,0,0))
            win2.blit(Windisplay,(300,385))
            pygame.display.update()
            pygame.time.delay(5000)
            pygame.quit()
            quit()
        man2.score-=1
        man2=player(5,5,50,50,man2.score,man2.c1,man2.c2,man2.c3,man2.c4)
        enemy1=enemy(175,445,50,50,0)
        enemy2=enemy(445,275,50,50,1)
        pygame.display.update()
        pygame.time.delay(1000)

    win2.fill((0,0,0))
    score=man2.check1()
        

    pygame.draw.rect(win2,(0,255,255),(man2.x,man2.y,man2.width,man2.height))
    enemy1.move1()
    enemy2.move1()
    pygame.draw.rect(win2,(255,0,0),(enemy1.x,enemy1.y,enemy1.width,enemy1.height))
    pygame.draw.rect(win2,(255,0,0),(enemy2.x,enemy2.y,enemy2.width,enemy2.height))
    pygame.draw.rect(win2,(255,255,255),(0,0,500,5))
    pygame.draw.rect(win2,(255,255,255),(0,0,5,500))
    pygame.draw.rect(win2,(255,255,255),(495,0,5,500))
    pygame.draw.rect(win2,(255,255,255),(0,495,500,105))
    pygame.draw.rect(win2,(255,255,255),(55,55,170,85))
    pygame.draw.rect(win2,(255,255,255),(55,55,85,170))
    pygame.draw.rect(win2,(255,255,255),(55,275,85,170))
    pygame.draw.rect(win2,(255,255,255),(55,360,170,85))
    pygame.draw.rect(win2,(255,255,255),(275,55,170,85))
    pygame.draw.rect(win2,(255,255,255),(360,55,85,170))
    pygame.draw.rect(win2,(255,255,255),(360,275,85,170))
    pygame.draw.rect(win2,(255,255,255),(275,360,170,85))
    pygame.draw.rect(win2,(255,255,255),(190,190,120,120))
    
    
        
    if not (man2.c1==1 and man2.c2==1 and man2.c3==1 and man2.c4==1):
        text=font.render("Score: "+str(score),1,(0,0,0))
        win2.blit(text,(200,525))
    faketime+=50
    if faketime==1000:
        faketime=0
        time+=1

    timetext=timefont.render("Time: "+str(time)+" s",1,(0,0,0))
    win2.blit(timetext,(350,525))
    name=pygame.font.SysFont("comicsans",30,True,True)
    namedisplay=name.render(str(nametext),1,(0,0,0))
    win2.blit(namedisplay,(15,525))
    
    pygame.display.update()

    if (man2.c1==1 and man2.c2==1 and man2.c3==1 and man2.c4==1):
        run1=False
   
man2=player(5,5,50,50,man2.score)
enemy1=enemy(175,445,50,50,0)
enemy2=enemy(615,445,50,50,0)
enemy3=enemy(615,5,50,50,0)
enemy4=enemy(885,275,50,50,1)

faketim=faketime
tim=time
fon=pygame.font.SysFont("comicsans",30,True,True)
win2=pygame.display.set_mode((940,550))
pygame.display.set_caption("PACMAN")
run2=True
while run2:
    pygame.time.delay(50)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            quit()
    man2.move2()

    if man2.x in range(enemy1.x-49,enemy1.x+50) and man2.y in range(enemy1.y-49,enemy1.y+50) or man2.x in range(enemy2.x-49,enemy2.x+50) and man2.y in range(enemy2.y-49,enemy2.y+50) or man2.x in range(enemy3.x-49,enemy3.x+50) and man2.y in range(enemy3.y-49,enemy3.y+50) or man2.x in range(enemy4.x-49,enemy4.x+50) and man2.y in range(enemy4.y-49,enemy4.y+50):
        crash.play()
        if man2.score==0:
            pygame.mixer.music.stop()
            game=pygame.font.SysFont("comicsans",50,True,True)
            gamedisplay=game.render("Game",1,(0,0,0))
            win2.blit(gamedisplay,(80,80))
            over=pygame.font.SysFont("comicsans",50,True,True)
            overdisplay=over.render("Over",1,(0,0,0))
            win2.blit(overdisplay,(740,80))
            you=pygame.font.SysFont("comicsans",50,True,True)
            youdisplay=you.render("You",1,(0,0,0))
            win2.blit(youdisplay,(80,385))
            Win=pygame.font.SysFont("comicsans",50,True,True)
            Windisplay=Win.render("Lose",1,(0,0,0))
            win2.blit(Windisplay,(740,385))
            pygame.display.update()
            pygame.time.delay(5000)
            pygame.quit()
            quit()
        man2.score-=1
        man2=player(5,5,50,50,man2.score,man2.c1,man2.c2,man2.c3,man2.c4,man2.d1,man2.d2,man2.d3,man2.d4,man2.d5,man2.d6,man2.d7)
        enemy1=enemy(175,445,50,50,0)
        enemy2=enemy(615,445,50,50,0)
        enemy3=enemy(615,5,50,50,0)
        enemy4=enemy(885,275,50,50,1)
        pygame.display.update()
        pygame.time.delay(1000)
    
    win2.fill((0,0,0))
    
    score=man2.check2()
    
    pygame.draw.rect(win2,(0,255,255),(man2.x,man2.y,man2.width,man2.height))
    enemy1.move2()
    enemy2.move2()
    enemy3.move2()
    enemy4.move2()
    pygame.draw.rect(win2,(255,0,0),(enemy2.x,enemy2.y,enemy2.width,enemy2.height))
    pygame.draw.rect(win2,(255,0,0),(enemy1.x,enemy1.y,enemy1.width,enemy1.height))
    pygame.draw.rect(win2,(255,0,0),(enemy3.x,enemy3.y,enemy3.width,enemy3.height))
    pygame.draw.rect(win2,(255,0,0),(enemy4.x,enemy4.y,enemy4.width,enemy4.height))
    pygame.draw.rect(win2,(255,255,255),(0,0,940,5))
    pygame.draw.rect(win2,(255,255,255),(0,0,5,500))
    pygame.draw.rect(win2,(255,255,255),(0,495,940,105))
    pygame.draw.rect(win2,(255,255,255),(935,0,5,500))
    pygame.draw.rect(win2,(255,255,255),(55,55,170,85))
    pygame.draw.rect(win2,(255,255,255),(55,55,85,170))
    pygame.draw.rect(win2,(255,255,255),(55,275,85,170))
    pygame.draw.rect(win2,(255,255,255),(55,360,170,85))
    pygame.draw.rect(win2,(255,255,255),(275,55,170,85))
    pygame.draw.rect(win2,(255,255,255),(360,55,85,170))
    pygame.draw.rect(win2,(255,255,255),(360,275,85,170))
    pygame.draw.rect(win2,(255,255,255),(275,360,170,85))
    pygame.draw.rect(win2,(255,255,255),(190,190,120,120))
    pygame.draw.rect(win2,(255,255,255),(495,55,170,85))
    pygame.draw.rect(win2,(255,255,255),(495,55,85,170))
    pygame.draw.rect(win2,(255,255,255),(495,275,85,170))
    pygame.draw.rect(win2,(255,255,255),(495,360,170,85))
    pygame.draw.rect(win2,(255,255,255),(715,55,170,85))
    pygame.draw.rect(win2,(255,255,255),(800,55,85,170))
    pygame.draw.rect(win2,(255,255,255),(800,275,85,170))
    pygame.draw.rect(win2,(255,255,255),(715,360,170,85))
    pygame.draw.rect(win2,(255,255,255),(630,190,120,120))
    if not (man2.d1==1 and man2.d2==1 and man2.d3==1 and man2.d4==1 and man2.d5==1 and man2.d6==1 and man2.d7==1):
        tex=fon.render("Score: "+str(man2.score),1,(0,0,0))
        win2.blit(tex,(420,525))
    faketim+=50
    if faketim==1000:
        faketim=0
        tim+=1

    timetex=timefon.render("Time: "+str(tim)+" s",1,(0,0,0))
    win2.blit(timetex,(570,525))
    name=pygame.font.SysFont("comicsans",30,True,True)
    namedisplay=name.render(str(nametext),1,(0,0,0))
    win2.blit(namedisplay,(15,525))

    pygame.display.update()

    if (man2.d1==1 and man2.d2==1 and man2.d3==1 and man2.d4==1 and man2.d5==1 and man2.d6==1 and man2.d7==1):
        pygame.mixer.music.stop()
        victory.play()
        run2=False
        game=pygame.font.SysFont("comicsans",50,True,True)
        gamedisplay=game.render("Game",1,(0,0,0))
        win2.blit(gamedisplay,(80,80))
        over=pygame.font.SysFont("comicsans",50,True,True)
        overdisplay=over.render("Over",1,(0,0,0))
        win2.blit(overdisplay,(740,80))
        you=pygame.font.SysFont("comicsans",50,True,True)
        youdisplay=you.render("You",1,(0,0,0))
        win2.blit(youdisplay,(80,385))
        Win=pygame.font.SysFont("comicsans",50,True,True)
        Windisplay=Win.render("win",1,(0,0,0))
        win2.blit(Windisplay,(740,385))
        pygame.display.update()
        pygame.time.delay(18000)
        
pygame.quit()
